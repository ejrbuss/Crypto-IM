package com.local.se360;

public class Message {
	
	public final String sender;
	public final String message;
	
	public Message(final String sender, final String message) {
		this.sender  = sender;
		this.message = message;
	}
}